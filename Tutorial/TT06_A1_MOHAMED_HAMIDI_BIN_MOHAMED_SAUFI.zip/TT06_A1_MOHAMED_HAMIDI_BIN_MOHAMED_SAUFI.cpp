/**********|**********|**********|
Program: TT06_A1_MOHAMED_HAMIDI_BIN_MOHAMED_SAUFI.cpp
Course: TCP1101 Programming Fundamentals
Year: 2017/18 Trimester 1
Name: Mohamed Hamidi bin Mohamed Saufi
ID: 1161303937
Email: hamidisaufi@gmail.com
Phone: 011-11392329
**********|**********|**********/

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

string newFileName(string textEnter);  //For creating a new file
string emptySpace(string textEnter);  //For adding empty spaces to tiles with respect to the length of string
string tableLine(string textEnter);  //For adding the table lines with respect to the length of string
string textInsert(string textEnter);  //Function for updating text in a tile
void insertWrongEmptyTiles(int tileNumber);  //Function to be called when the tiles selected has empty previous tile
void emptyTextInTiles();  //Function to be called in the attempt to overwrite text in an empty tile

int main()
{
  char menu;
  string filename;
  int tile;
  string text[8] = { " "," "," "," "," "," "," "," " };
  string emptySpaces[8] = { " "," "," "," "," "," "," "," " };
  string tableLines[8] = { "-","-","-","-","-","-","-","-" };  //Default table arrays
  int newFile = 0;
  int insertText = 0;
  int deleteText = 0;
  int overwriteText = 0;
  cout << endl;
  cout << "Welcome to the One Line Stone-Age Tiled Editor" << endl;
  cout << "What do you want to do today?" << endl;
  cout << endl;
  cout << "File name: NULL" << endl;
  cout << endl;
  do
  {
    cout << "*============================================================" << endl;
    cout << endl;
    cout << "[N]ew, " << "[I]nsert, " << "[D]elete, " << "[O]verwrite, " << "[Q]uit" << endl;
    cout << "==> ";
    cin >> menu;
    cout << endl;

    if (menu == 'q' || menu == 'Q') {
      cout << "Thank you for using One Line Stone-Age Tiled Editor" << endl;
      cout << endl;
      cout << "Here are your final stats:-" << endl;
      cout << "Number of new file attempt: " << newFile << endl;
      cout << "Number of insert attempt: " << insertText << endl;
      cout << "Number of delete attempt: " << deleteText << endl;
      cout << "Number of overwrite attempt: " << overwriteText << endl;
      cout << endl;
    }

    else {
      if (filename == "") {    //When there is no new file created
        if (menu == 'n' || menu == 'N') {
          newFile += 1;

          filename = newFileName(filename);
          system("cls");
          cout << endl;
          cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
          cout << "|    |" << emptySpaces[0] << "1 |" << emptySpaces[1] << "2 |" << emptySpaces[2] << "3 |" << emptySpaces[3] << "4 |" << emptySpaces[4] << "5 |" << emptySpaces[5] << "6 |" << emptySpaces[6] << "7 |" << emptySpaces[7] << "8 |" << endl;
          cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
          cout << "| 00 | " << text[0] << " | " << text[1] << " | " << text[2] << " | " << text[3] << " | " << text[4] << " | " << text[5] << " | " << text[6] << " | " << text[7] << " |" << endl;
          cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
          cout << endl;
          cout << "File name: " << filename << ".txt" << endl;
          cout << endl;
        }

        else if (menu == 'I' || menu == 'i' || menu == 'D' || menu == 'd' || menu == 'O' || menu == 'o') {
          system("cls");
          cout << endl;
          cout << "No new file detected. Please create a new one" << endl;
        }

        else {
          system("cls");
          cout << endl;			
          cout << "Invalid command. Please try again" << endl;
        }
      }

      else {    //When a new file is created
        if (menu == 'n' || menu == 'N') {
          newFile += 1;
          for (int i = 0; i < 8; i++)
          {
            text[i] = " ";
            emptySpaces[i] = " ";
            tableLines[i] = "-";
          }
		  
          filename = newFileName(filename);
          system("cls");
        }

        else if (menu == 'i' || menu == 'I') {
          insertText += 1;

          if (text[0] == " ") {
            cout << "Tile number ==> 1" << endl;
            text[0] = textInsert(text[0]);
            system ("cls");
            emptySpaces[0] = emptySpace(text[0]);
            tableLines[0] = tableLine(text[0]);
          }

          else {
            do 
            {
              cout << "Tile number ==> ";
              cin >> tile;

              switch (tile)
              {
              case 1:
                if (text[7] == " ") {
                  for (int i = 7; i > 0; i--)
                  {
                    text[i] = text[i - 1];
                    emptySpaces[i] = emptySpaces[i - 1];
                    tableLines[i] = tableLines[i - 1];
                  }

                text[0] = textInsert(text[0]);
                emptySpaces[0] = emptySpace(text[0]);
                tableLines[0] = tableLine(text[0]);
                }

                else {
                  system ("cls");
                  cout << endl;
                  cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                }
                break;

              case 3:
              case 4:
              case 5:
              case 6:
              case 7:
              case 8:
                if (text[1] == " ") {
                  insertWrongEmptyTiles(2);
                }
				
              case 2:
                if (text[1] == " ") {
                  text[1] = textInsert(text[1]);
                  emptySpaces[1] = emptySpace(text[1]);
                  tableLines[1] = tableLine(text[1]);
                }
				
                else {
                  switch (tile)
                  {
                  case 2:
                    if (text[7] == " ") {
                      for (int i = 7; i > 1; i--)
                      {
                        text[i] = text[i - 1];
                        emptySpaces[i] = emptySpaces[i - 1];
                        tableLines[i] = tableLines[i - 1];
                      }

                    text[1] = textInsert(text[1]);
                    emptySpaces[1] = emptySpace(text[1]);
                    tableLines[1] = tableLine(text[1]);
                    }

                    else {
                      system ("cls");
                      cout << endl;
                      cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                    }
                    break;

                  case 4:
                  case 5:
                  case 6:
                  case 7:
                  case 8:
                    if (text[2] == " ") {
                      insertWrongEmptyTiles(3);
                    }

                  case 3:
                    if (text[2] == " ") {
                      text[2] = textInsert(text[2]);
                      emptySpaces[2] = emptySpace(text[2]);
                      tableLines[2] = tableLine(text[2]);
                    }
					  
                    else {
                      switch (tile)
                      {
                      case 3:
                        if (text[7] == " ") {
                          for (int i = 7; i > 2; i--)
                          {
                            text[i] = text[i - 1];
                            emptySpaces[i] = emptySpaces[i - 1];
                            tableLines[i] = tableLines[i - 1];
                          }

                          text[2] = textInsert(text[2]);
                          emptySpaces[2] = emptySpace(text[2]);
                          tableLines[2] = tableLine(text[2]);
                        }

                        else {
                          system ("cls");
                          cout << endl;
                          cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                        }
                        break;

                      case 5:
                      case 6:
                      case 7:
                      case 8:
                        if (text[3] == " ") {
                          insertWrongEmptyTiles(4);
                        }

                      case 4:
                        if (text[3] == " ") {
                          text[3] = textInsert(text[3]);
                          emptySpaces[3] = emptySpace(text[3]);
                          tableLines[3] = tableLine(text[3]);
                        }

                        else {
                          switch (tile)
                          {
                          case 4:
                            if (text[7] == " ") {
                              for (int i = 7; i > 3; i--)
                              {
                                text[i] = text[i - 1];
                                emptySpaces[i] = emptySpaces[i - 1];
                                tableLines[i] = tableLines[i - 1];
                              }

                              text[3] = textInsert(text[3]);
                              emptySpaces[3] = emptySpace(text[3]);
                              tableLines[3] = tableLine(text[3]);
                            }

                            else {
                              system ("cls");
                              cout << endl;           
                              cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                            }
                            break;

                          case 6:
                          case 7:
                          case 8:
                            if (text[4] == " ") {
                              insertWrongEmptyTiles(5);
                            }

                          case 5:
                            if (text[4] == " ") {
                              text[4] = textInsert(text[4]);
                              emptySpaces[4] = emptySpace(text[4]);
                              tableLines[4] = tableLine(text[4]);
                            }

                            else {
                              switch (tile)
                              {
                              case 5:
                                if (text[7] == " ") {
                                  for (int i = 7; i > 4; i--)
                                  {
                                    text[i] = text[i - 1];
                                    emptySpaces[i] = emptySpaces[i - 1];
                                    tableLines[i] = tableLines[i - 1];
                                  }

                                  text[4] = textInsert(text[4]);
                                  emptySpaces[4] = emptySpace(text[4]);
                                  tableLines[4] = tableLine(text[4]);
                                }

                                else {
                                  system ("cls");
                                  cout << endl;  
                                  cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                                }
                                break;

                              case 7:
                              case 8:
                                if (text[5] == " ") {
                                  insertWrongEmptyTiles(6);
                                }

                              case 6:
                                if (text[5] == " ") {
                                  text[5] = textInsert(text[5]);
                                  emptySpaces[5] = emptySpace(text[5]);
                                  tableLines[5] = tableLine(text[5]);
                                }

                                else {
                                  switch (tile)
                                  {
                                  case 6:
                                    if (text[7] == " ") {
                                      for (int i = 7; i > 5; i--)
                                      {
                                        text[i] = text[i - 1];
                                        emptySpaces[i] = emptySpaces[i - 1];
                                        tableLines[i] = tableLines[i - 1];
                                      }

                                      text[5] = textInsert(text[5]);
                                      emptySpaces[5] = emptySpace(text[5]);
                                      tableLines[5] = tableLine(text[5]);
                                    }

                                    else {
                                      system ("cls");
                                      cout << endl;  
                                      cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                                    }
                                    break;

                                  case 8:
                                    if (text[6] == " ") {
                                      insertWrongEmptyTiles(7);
                                    }

                                  case 7:
                                    if (text[6] == " ") {
                                      text[6] = textInsert(text[6]);
                                      emptySpaces[6] = emptySpace(text[6]);
                                      tableLines[6] = tableLine(text[6]);
                                    }

                                    else {
                                      switch (tile)
                                      {
                                      case 7:
                                        if (text[7] == " ") {
                                          for (int i = 7; i > 5; i--)
                                          {
                                            text[i] = text[i - 1];
                                            emptySpaces[i] = emptySpaces[i - 1];
                                            tableLines[i] = tableLines[i - 1];
                                          }

                                          text[5] = textInsert(text[5]);
                                          emptySpaces[5] = emptySpace(text[5]);
                                          tableLines[5] = tableLine(text[5]);
                                        }

                                        else {
                                          system ("cls");
                                          cout << endl;  
                                          cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                                        }
                                        break;

                                      case 8:
                                        if (text[7] == " ") {
                                          text[7] = textInsert(text[7]);
                                          emptySpaces[7] = emptySpace(text[7]);
                                          tableLines[7] = tableLine(text[7]);
                                        }

                                        else {
                                          switch (tile)
                                          {
                                          case 1:
                                          case 2:
                                          case 3:
                                          case 4:
                                          case 5:
                                          case 6:
                                          case 7:
                                          case 8:
                                            system ("cls");
                                            cout << endl;
                                            cout << "The tiles are full. Please delete or overwrite a tile" << endl;
                                            break;

                                          default:
                                            cout << endl;
                                            cout << "Invalid tile number. Please try again" << endl;
                                            break;
                                          }
                                        }
                                        break;

                                      default:
                                        cout << endl;
                                        cout << "Invalid tile number. Please try again" << endl;
                                        break;
                                      }
                                    }
                                    break;

                                  default:
                                    cout << endl;
                                    cout << "Invalid tile number. Please try again" << endl;
                                    break;
                                  }
                                }
                                break;

                              default:
                                cout << endl;
                                cout << "Invalid tile number. Please try again" << endl;
                                break;
                              }
                            }
                            break;

                          default:
                            cout << endl;
                            cout << "Invalid tile number. Please try again" << endl;
                            break;
                          }
                        }
                        break;

                      default:
                        cout << endl;
                        cout << "Invalid tile number. Please try again" << endl;
                        break;
                      }
                    }
                    break;

                  default:
                    cout << endl;
                    cout << "Invalid tile number. Please try again" << endl;
                    break;
                  }
                }
                break;

              default:
                cout << endl;
                cout << "Invalid tile number. Please try again" << endl;
                break;
              }
            } while (tile != 1 && tile != 2 && tile != 3 && tile != 4 && tile != 5 && tile != 6 && tile != 7 && tile != 8);
          }
        }

        else if (menu == 'd' || menu == 'D') {
          deleteText += 1;

          do 
          {
            cout << "Tile number ==> ";
            cin >> tile;
            switch (tile)
            {
            case 1:
              if (text[0] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 0; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              
              break;

            case 2:
              if (text[1] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 1; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 3:
              if (text[2] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 2; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 4:
              if (text[3] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 3; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 5:
              if (text[4] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 4; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 6:
              if (text[5] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 5; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 7:
              if (text[6] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
                for (int i = 6; i < 7; i++)
                {
                  text[i] = text[i + 1];
                  emptySpaces[i] = emptySpaces[i + 1];
                  tableLines[i] = tableLines[i + 1];
                }

               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            case 8:
              if (text[7] == " ") {
                system("cls");
                emptyTextInTiles();
              }
			  
              else {
               text[7] = " ";
               emptySpaces[7] = " ";
               tableLines[7] = "-";
               system("cls");
              }
              break;

            default:
              cout << endl;
              cout << "Invalid tile number. Please try again" << endl;
              break;
            }
          }while (tile != 1 && tile != 2 && tile != 3 && tile != 4 && tile != 5 && tile != 6 && tile != 7 && tile != 8);
        }

        else if (menu == 'o' || menu == 'O') {
          overwriteText += 1;

          do
          {
            cout << "Tile number ==> ";
            cin >> tile;

            switch (tile)
            {
            case 1:
              if (text[0] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[0] = " ";
                text[0] = textInsert(text[0]);
                emptySpaces[0] = emptySpace(text[0]);
                tableLines[0] = tableLine(text[0]);
              }
              break;

              case 2:
              if (text[1] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[1] = " ";
                text[1] = textInsert(text[1]);
                emptySpaces[1] = emptySpace(text[1]);
                tableLines[1] = tableLine(text[1]);
              }
              break;

            case 3:
              if (text[2] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[2] = " ";
                text[2] = textInsert(text[2]);
                emptySpaces[2] = emptySpace(text[2]);
                tableLines[2] = tableLine(text[2]);
              }
              break;

            case 4:
              if (text[3] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[3] = " ";
                text[3] = textInsert(text[3]);
                emptySpaces[3] = emptySpace(text[3]);
                tableLines[3] = tableLine(text[3]);
              }
              break;

            case 5:
              if (text[4] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[4] = " ";
                text[4] = textInsert(text[4]);
                emptySpaces[4] = emptySpace(text[4]);
                tableLines[4] = tableLine(text[4]);
              }
              break;

            case 6:
              if (text[5] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[5] = " ";
                text[5] = textInsert(text[5]);
                emptySpaces[5] = emptySpace(text[5]);
                tableLines[5] = tableLine(text[5]);
              }
              break;

            case 7:
              if (text[6] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[6] = " ";
                text[6] = textInsert(text[6]);
                emptySpaces[6] = emptySpace(text[6]);
                tableLines[6] = tableLine(text[6]);
              }
              break;

            case 8:
              if (text[7] == " ") {
                system("cls");
                emptyTextInTiles();
              }

              else {
                text[7] = " ";
                text[7] = textInsert(text[7]);
                emptySpaces[7] = emptySpace(text[7]);
                tableLines[7] = tableLine(text[7]);
              }
              break;

            default:
              cout << endl;
              cout << "Invalid tile number. Please try again" << endl;
              break;
            }
          } while (tile != 1 && tile != 2 && tile != 3 && tile != 4 && tile != 5 && tile != 6 && tile != 7 && tile != 8);
        }

        else {
          system("cls");
          cout << endl;
          cout << "Invalid command. Please try again" << endl;
        }

        cout << endl;
        cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
        cout << "|    |" << emptySpaces[0] << "1 |" << emptySpaces[1] << "2 |" << emptySpaces[2] << "3 |" << emptySpaces[3] << "4 |" << emptySpaces[4] << "5 |" << emptySpaces[5] << "6 |" << emptySpaces[6] << "7 |" << emptySpaces[7] << "8 |" << endl;
        cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
        cout << "| 00 | " << text[0] << " | " << text[1] << " | " << text[2] << " | " << text[3] << " | " << text[4] << " | " << text[5] << " | " << text[6] << " | " << text[7] << " |" << endl;
        cout << "|----+" << tableLines[0] << "--+" << tableLines[1] << "--+" << tableLines[2] << "--+" << tableLines[3] << "--+" << tableLines[4] << "--+" << tableLines[5] << "--+" << tableLines[6] << "--+" << tableLines[7] << "--|" << endl;
        cout << endl;
        cout << "File name: " << filename << ".txt" << endl;
        cout << endl;

      }
    }
  } while (menu != 'q' && menu != 'Q');
  return 0;
}

void emptyTextInTiles()
{
  cout << endl;
  cout << "No text detected in selected tile" << endl;
  return;
}

string newFileName(string textEnter) 
{
  cout << "Please enter your file name" << endl;
  cout << "New file name ==> ";
  cin >> textEnter;
  cout << endl;
  return textEnter;
}

string textInsert(string textEnter)
{
  cout << "Text ==> ";
  cin >> textEnter;
  cout << endl;
  system("cls");
  return textEnter;
}

void insertWrongEmptyTiles(int tileNumber)
{
  cout << endl;
  cout << "Please fill out tile number " << tileNumber << " first" << endl;
  cout << "Tile number ==> " << tileNumber << endl;
  return;
}

string emptySpace(string textEnter)
{
  string emptySp = "";
  for (int i = 0; i < textEnter.length(); i++)
  {
    emptySp += " ";
  }
  return emptySp;
}

string tableLine(string textEnter)
{
  string tableLi = "";
  for (int i = 0; i < textEnter.length(); i++)
  {
    tableLi += "-";
  }
  return tableLi;
}