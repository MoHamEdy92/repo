//  -------------------------------------------------------------
//  Question 5:   Write a program
//  -------------------------------------------------------------
/****************************************************************

Refer to the flowchart in the file q5FlowChart.jpg.

Write a C++ program according to the flow chart and test it with
the following sample runs. 

Sample Run 1:

Enter integer A: 5
Enter integer B: 7

Result = 2

Sample Run 2:
Enter integer A: 40
Enter integer B: 34

Result = 6

****************************************************************/

// Note: In the coming lab test there might be questions 
// based on flow chart and/or pseudocode.
