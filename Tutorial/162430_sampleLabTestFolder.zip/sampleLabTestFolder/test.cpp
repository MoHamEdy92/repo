#include <iostream> 
using namespace std

int main()
{
	cout << "Good day!" << endl;

	return 0;
}
